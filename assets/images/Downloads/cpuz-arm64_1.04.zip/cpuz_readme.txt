
CPU-Z ARM64 Readme file
------------------------

Version 1.04
June 2024
Contact : cpuz@cpuid.com
Web page: https://www.cpuid.com/softwares/cpu-z-arm64.html


History
-------
-----------------------------------------------------------------------------------------------------------
1.04 - June 2024
- Improved support of Qualcomm Snapdragon X Elite & Plus.
- Qualcomm Snapdragon 720G.

-----------------------------------------------------------------------------------------------------------
1.03 - April 2024
- Qualcomm Snapdragon X Elite and Snapdragon X Plus.
- Qualcomm Snapdragon 888, Snapdragon 850, Snapdragon 680.
- Rockchip RK3568.
- NXP i.MX8MP (4x ARM Cortex-A53).
- NXP Layerscape LX2160A (16x ARM Cortex-A72), Layerscape LX2120A (12x ARM Cortex-A72), Layerscape LX2080A (8x ARM Cortex-A72).
- Microsoft SQ2.

-----------------------------------------------------------------------------------------------------------
1.02 - February 2024
- Qualcomm Snapdragon 808, Snapdragon 810, Snapdragon 845, Snapdragon 855, Snapdragon 860, Snapdragon 7c.
- Broadcom BCM2711, BCM2712, BCM2837.
- Rockchip RK3588, RK3588S.
- Microsoft SQ1.
- Added benchmark tab.

-----------------------------------------------------------------------------------------------------------
1.01 - January 2024
- First release.
